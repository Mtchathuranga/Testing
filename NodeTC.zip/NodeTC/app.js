const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const mongoose = require('mongoose');
const config = require('./config/database');
const Routes = require("./routes/Routes");
const path = require('path');
const connection = mongoose.connect(config.database);

const PORT = process.env.PORT || 3000
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())

require('./routes/test/testRoutes')(app);

mongoose.Promise = global.Promise;
mongoose.connect(config.database)
.then(() => {
    console.log("Successfully connected to the database");    
}).catch(err => {
    console.log('Could not connect to the database. Exiting now...');
    process.exit();
});

app.get('/', function (req, res) {
    res.send('hello server..!!')
});

app.listen(PORT,function(){
    console.log("Listing to the port - "+PORT);
});
