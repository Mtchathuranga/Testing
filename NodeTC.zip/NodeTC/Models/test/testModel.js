const mongoose = require('mongoose')

var note = mongoose.Schema({
    title: String,
    content: String
},
{
    timestamps: true
})

var user = mongoose.Schema({
    userName: String,
    pswrd: String
},
{
    timestamps: true
})

module.exports = mongoose.model('Notes', note)
module.exports = mongoose.model('users', user)