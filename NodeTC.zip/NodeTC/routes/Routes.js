const express = require('express');
const router = express.Router();

router.get("/register",function (req,res) {
    res.send('hello register View') ;   
})

router.get("",function (req,res) {
    res.send('hello user View') ;   
})

module.exports = router;