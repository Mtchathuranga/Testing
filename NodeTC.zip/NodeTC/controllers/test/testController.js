const notes = require('../../models/test/testModel')
const users = require('../../models/test/testModel')


exports.userLogIn = (req, res) => {    

    if (!req.body.userName) {
        return res.status(400).send({
            message: 'Content empty'
        })
    }

    new users({        
        userName: req.body.userName || 'untitled note',
        pswrd: req.body.pswrd
    }).save()
        .then(data =>{           
            res.send(data)
        })
        .catch(err =>{
            res.status(500).send({
                message: err.message || 'Some errors occured'
            })
        })
}

exports.create = (req, res) => {
    console.log(req.body.title);

    if (!req.body.content) {
        return res.status(400).send({
            message: 'Content empty'
        })
    }
    

    new notes({
        title: req.body.title || 'untitled note',
        content: req.body.content
    }).save()
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || 'Some errors occured'
            })
        })
}

exports.findAll = (req, res) => {

    notes.find()
        .then(nts => {
            res.send(nts)
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || 'Some erros occured'
            })
        })

}

exports.findOne = (req, res) => {
    notes.findById(req.params.noteId)
        .then(nts => {
            if (!nts) {
                return res.status(404).send({
                    message: 'note not found'
                })
            }

            res.send(nts)

        })
        .catch(err => {
            if (err.kind === 'ObjectId') {
                return res.status(404).send({
                    message: 'note not found ' + req.params.noteId
                })
            }

            return res.status(500).send({
                message: 'error retrieve note with id ' + req.params.noteId
            })

        })
}

exports.update = (req, res) => {

    if (!req.body.content) {
        return res.status(400).send({
            message: 'Note content canot be empty'
        })
    }

    notes.findByIdAndUpdate(req.params.noteId, {

        title: req.body.title || 'Untitled Note',
        content: req.body.content

    }, { new: true })
        .then(note => {
            if (!note) {
                return res.status(404).send({
                    message: 'Note not found with id ' + req.params.noteId
                })
            }
            res.send(note);

        }).catch(err => {
            if (err.kind === 'ObjectId') {
                return res.send.status(404).send({
                    message: 'notes not found ' + req.params.noteId
                })
            }

            return res.status(500).send({
                message: 'error updating ' + req.params.noteId
            })

        })

}

exports.delete = (req, res) => {

    notes.findByIdAndRemove(req.params.noteId)
        .then(nts => {
            if (!nts) {
                return res.status(404).send({
                    message: 'note not found with id ' + req.params.noteId
                })
            }

            res.send({
                message: 'note deleted'
            })

        })
        .catch(err => {
            if (err.kind === 'ObjectId' || err.name === 'NotFound') {
                return res.status(404).send({
                    message: 'Notes not dound with id ' + req.params.noteId
                })
            }

            return res.status(500).send({
                message: "Could not delete " + req.params.noteId
            })

        })

}